## MetaData.json file for use with State of decay 2 Mod Manager

# Unreal Engine Uasset Viewer/Editor

## Can unpack and read/edit assets from engine versions 4.11 - 4.26

## 5.00 compatability is being worked on.

A tool for viewing and editing the data in uasset/uexp/umap files from games made in unreal engine.

Also able to unpack and create new pak files

Originally built with lots of feedback and testing from the [State of Decay 2 Modding Discord]( https://discord.gg/emhxg5d )

If you find the tool helpful and wish to help support my work, feedback, suggestions and constructive criticism are always welcome.
You can also donate via my [paypal](https://www.paypal.com/paypalme/KaiHeilos)
